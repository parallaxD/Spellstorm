using UnityEngine.Tilemaps;

[System.Serializable]
public class MyTile
{
    public TileBase Sprite;

    public float Weight;
}
