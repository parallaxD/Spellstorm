using System;

public enum ElementType
{
    Fire,
    Water,
    Earth,
    Wind
}
